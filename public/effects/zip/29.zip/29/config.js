var effectData = {
	framePos: {
		x: 0.3,
		y: 0,
	},
	frameScale: 1,
};

var state = 0; //0 = narrator, 1 = man
const settings = {
	global: {
		headRotSens: 1.2,
	},
};

function Effect() {
	var self = this;

	this.update = function () {
		const rotation = getHeadRotation();
		if (rotation === -1) {
			setFarmerMask();
		} else if (rotation === 1) {
			setNarratorMask();
		}
	};

	this.init = function () {
		Api.meshfxMsg("spawn", 104, 0, "!glfx_FACE");
		Api.meshfxMsg("spawn", 4, 0, "background.bsm2");

		Api.meshfxMsg(
			"shaderVec4",
			6,
			0,
			effectData.framePos.x +
				" " +
				effectData.framePos.y +
				" " +
				effectData.frameScale +
				" 0"
		);
		Api.showRecordButton();
	};

	this.restart = function () {
		Api.meshfxReset();
		self.init();
	};

	this.faceActions = [self.update];
	this.noFaceActions = [];

	this.videoRecordStartActions = [];
	this.videoRecordFinishActions = [];
	this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());

function setFarmerMask() {
	removeMask();
	Api.meshfxMsg("spawn", 0, 0, "farmer_2emesh.bsm2");
	state = 1;
}

function setNarratorMask() {
	removeMask();
}

function removeMask() {
	if (state === 1 || state === 2) {
		Api.meshfxMsg("del", 0);
	}
	state = 0;
}

function getHeadRotation() {
	const mv = Api.modelview();
	const rot = -mv[2] * settings.global.headRotSens;

	if (rot <= -0.55555) return -1; // left
	if (rot <= 0.55555) return 0;
	// center
	else return 1; // right
}
