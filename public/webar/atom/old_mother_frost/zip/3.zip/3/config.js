var state = 0; //0 = narrator, 1 = man
var headMoved = false;
const settings = {
    global: {
        headRotSens: 1.2,
    }
}

function Effect() {
    var self = this;

    this.update = function () { 
        const rotation = getHeadRotation();
        if(rotation === -1) {
            setBreadMask();
        } else if(rotation === 1) {
            setNarratorMask();
        }
    }


    this.init = function() {
        Api.meshfxMsg("spawn", 104, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 4, 0, "quad.bsm2");
        
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [self.update];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());

function setBreadMask(){
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "bread_2bmesh.bsm2");
    state = 1;    
}

function removeMask() {
    if(state===1) {
        Api.meshfxMsg("del", 0);
    } 
    state = 0;
}

function setNarratorMask() {
    removeMask();
}

function getHeadRotation() {
    const mv = Api.modelview();
    const rot = (-mv[2]) * settings.global.headRotSens;

    if (rot <= -0.33333) return -1;     // left
	if (rot <= 0.33333) return 0;       // center
	else return 1;                      // right
}