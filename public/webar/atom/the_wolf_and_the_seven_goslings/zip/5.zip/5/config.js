var state = 0; //0 = narrator, 1 = red wren, 2 = pink wren
const settings = {
    global: {
        headRotSens: 1.2,
    },
}

var effectData = {
    framePos: {
        x: 1,
        y: 0.8,
    },
    frameScale: 0.65
}

function Effect() {
    var self = this;

    this.init = function() {
        Api.meshfxMsg("spawn", 104, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 3, 0, "quad.bsm2");
        Api.meshfxMsg("spawn", 4, 0, "quad2.bsm2");
        Api.meshfxMsg("shaderVec4", 6, 0, effectData.framePos.x + " " + effectData.framePos.y + " " + effectData.frameScale + " 0");
        self.faceActions = [];
        
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());