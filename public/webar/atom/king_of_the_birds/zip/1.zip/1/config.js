var state = 0; //0 = narrator, 1 = bear, 2 = wolf
const settings = {
    global: {
        headRotSens: 1.2,
    }
}

function Effect() {
    var self = this;

    this.update = function () { 
        const rotation = getHeadRotation();
        if(rotation === -1) {
            setBearMask();
        } else if(rotation === 1) {
            setWolfMask();
        } else if(rotation === 0 && !getEyesStatus()[0]) {
            setNarratorMask();
        }
    }

    this.init = function() {
        Api.meshfxMsg("spawn", 104, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 3, 0, "quad.bsm2");
        
        Api.playSound('bird.ogg', false, 1);
        self.faceActions = [self.update];
        
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());

function setBearMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "bear_face.bsm2");
    Api.meshfxMsg("spawn", 1, 0, "bear_hair.bsm2");
    Api.meshfxMsg("spawn", 2, 0, "bear_nose.bsm2");
    state = 1;
}

function setWolfMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "wolf.bsm2");
    state = 2;
}

function removeMask() {
    if(state===1) {
        Api.meshfxMsg("del", 0);
        Api.meshfxMsg("del", 1);
        Api.meshfxMsg("del", 2);
    } else if(state===2){
        Api.meshfxMsg("del", 0);
    }
    state = 0;
}

function setNarratorMask() {
    removeMask();
}

function getHeadRotation() {
    const mv = Api.modelview();
    const rot = (-mv[2]) * settings.global.headRotSens;

    if (rot <= -0.33333) return -1;     // left
	if (rot <= 0.33333) return 0;       // center
	else return 1;                      // right
}
